"""
==============================================================================
Student Academic Progression and Portfolio Management System
Database Access Layer & 3NF Query Helpers (database.py)
==============================================================================
This module encapsulates all SQLite database operations:
- Connection management with strict foreign-key enforcement
- Schema initialization from schema.sql
- Rich sample data seeding for realistic faculty demonstration
- Parameterized CRUD functions avoiding SQL injection vulnerabilities
- Aggregation and analytics queries for dashboard & Chart.js
- Sync audit logging
"""

import os
import sqlite3
from datetime import datetime

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "student_progression.db")
SCHEMA_PATH = os.path.join(BASE_DIR, "schema.sql")


def get_db():
    """
    Establish and return a connection to the SQLite database.
    - row_factory is set to sqlite3.Row for dict-like column access
    - PRAGMA foreign_keys = ON is executed immediately to guarantee
      referential integrity and cascade actions.
    """
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON;")
    return conn


def init_db(seed=True):
    """
    Initialize the database using schema.sql and seed sample data if empty.
    """
    if not os.path.exists(SCHEMA_PATH):
        raise FileNotFoundError(f"schema.sql not found at {SCHEMA_PATH}")

    with open(SCHEMA_PATH, "r", encoding="utf-8") as f:
        schema_sql = f.read()

    with get_db() as conn:
        conn.executescript(schema_sql)

        # Seed categories if missing
        cats = [
            ("Coding Contest & Hackathon", "Technical"),
            ("Research Paper Presentation", "Technical"),
            ("Robotics & IoT Projects", "Technical"),
            ("Technical Workshop & Seminar", "Technical"),
            ("Industry Internship", "Co-curricular"),
            ("Project Exhibition", "Co-curricular"),
            ("Tech Symposium & Quiz", "Co-curricular"),
            ("Open Source Contribution", "Co-curricular"),
            ("Sports & Athletics", "Extra-curricular"),
            ("Cultural Fest & Performing Arts", "Extra-curricular"),
            ("Debate & Literary Events", "Extra-curricular"),
            ("Student Council & Leadership", "Extra-curricular"),
            ("Social Volunteering & NSS", "Extra-curricular"),
        ]
        for name, ctype in cats:
            conn.execute(
                "INSERT OR IGNORE INTO activity_categories(name, activity_type) VALUES(?, ?)",
                (name, ctype),
            )

        # Seed master subjects if empty
        sub_count = conn.execute("SELECT COUNT(*) FROM subjects").fetchone()[0]
        if sub_count == 0:
            subjects = [
                ("CS101", "Data Structures & Algorithms", "Theory", 4, 100.0),
                ("CS102", "Data Structures Laboratory", "Lab", 2, 50.0),
                ("CS201", "Database Management Systems", "Theory", 4, 100.0),
                ("CS202", "Database Systems Laboratory", "Lab", 2, 50.0),
                ("CS301", "Operating Systems", "Theory", 4, 100.0),
                ("CS302", "Operating Systems Laboratory", "Lab", 2, 50.0),
                ("CS401", "Computer Networks", "Theory", 4, 100.0),
                ("CS402", "Network & Security Laboratory", "Lab", 2, 50.0),
                ("CS501", "Software Engineering & Agile", "Theory", 3, 100.0),
                ("CS502", "Web Technologies Laboratory", "Lab", 2, 50.0),
                ("CS601", "Cloud Computing & Distributed Systems", "Theory", 4, 100.0),
                ("CS602", "Cloud Computing Laboratory", "Lab", 2, 50.0),
                ("CS701", "Artificial Intelligence & Machine Learning", "Theory", 4, 100.0),
                ("CS702", "AI & Machine Learning Laboratory", "Lab", 2, 50.0),
                ("CS801", "Capstone Major Project", "Lab", 6, 200.0),
            ]
            for code, name, stype, credits, max_m in subjects:
                conn.execute(
                    """INSERT OR IGNORE INTO subjects(subject_code, subject_name, subject_type, credits, default_max_marks)
                       VALUES(?, ?, ?, ?, ?)""",
                    (code, name, stype, credits, max_m),
                )

        if seed:
            seed_sample_data(conn)


def seed_sample_data(conn):
    """
    Populates rich, multi-student demonstration records.
    Demonstrates:
    - Normal academic progression through 6-7 semesters
    - Student with an official Gap Year (Drop year)
    - Student with missing semester record (unrecorded sem 2)
    - Subject theory and lab marks
    - Internal and external seminars
    - Technical, co-curricular, and extra-curricular achievements
    """
    student_count = conn.execute("SELECT COUNT(*) FROM students").fetchone()[0]
    if student_count > 0:
        return  # Already populated

    print("[database.py] Seeding demonstration records...")

    # Student 1: Aarav Sharma (Top performer, 6 semesters, seminars, hackathon)
    c1 = conn.execute(
        """INSERT INTO students(roll_no, full_name, email, phone, department, admission_year,
                               secondary_percent, higher_secondary_percent, current_semester, current_status)
           VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
        (
            "CE-2021-042",
            "Aarav Sharma",
            "aarav.sharma@example.edu",
            "+91 98765 43210",
            "Computer Engineering",
            2021,
            92.4,
            89.6,
            7,
            "Active",
        ),
    )
    s1_id = c1.lastrowid

    # Semesters for Aarav
    s1_sems = [
        (1, "2021-2022", 8.50, 8.50, "Completed", "Strong core performance"),
        (2, "2021-2022", 8.75, 8.63, "Completed", "Excellence in data structures"),
        (3, "2022-2023", 8.90, 8.72, "Completed", "Database topper"),
        (4, "2022-2023", 9.10, 8.81, "Completed", "Published research paper"),
        (5, "2023-2024", 8.80, 8.81, "Completed", "Consistent track record"),
        (6, "2023-2024", 9.25, 8.88, "Completed", "High distinction in Cloud"),
    ]
    sem_ids_s1 = {}
    for sem_no, ac_yr, sgpa, cgpa, st, rem in s1_sems:
        cur = conn.execute(
            """INSERT INTO semesters(student_id, semester_no, academic_year, sgpa, cgpa, status, remarks)
               VALUES(?, ?, ?, ?, ?, ?, ?)""",
            (s1_id, sem_no, ac_yr, sgpa, cgpa, st, rem),
        )
        sem_ids_s1[sem_no] = cur.lastrowid

    # Student 2: Priya Nair (Recorded Academic Gap / Medical Leave year between Sem 2 and Sem 3)
    c2 = conn.execute(
        """INSERT INTO students(roll_no, full_name, email, phone, department, admission_year,
                               secondary_percent, higher_secondary_percent, current_semester, current_status)
           VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
        (
            "CE-2020-015",
            "Priya Nair",
            "priya.nair@example.edu",
            "+91 98765 43211",
            "Computer Engineering",
            2020,
            88.0,
            84.5,
            8,
            "Active",
        ),
    )
    s2_id = c2.lastrowid

    # Semesters for Priya (Note: Sem 1 & 2 in 2020-21, Gap in 2021-22, Sem 3 & 4 in 2022-23)
    s2_sems = [
        (1, "2020-2021", 8.20, 8.20, "Completed", "First year foundation"),
        (2, "2020-2021", 8.40, 8.30, "Completed", "Good analytical skills"),
        (3, "2022-2023", 8.10, 8.23, "Completed", "Resumed after medical recovery"),
        (4, "2022-2023", 8.50, 8.30, "Completed", "Rapid academic bounce-back"),
        (5, "2023-2024", 8.60, 8.36, "Completed", "Project team lead"),
        (6, "2023-2024", 8.75, 8.42, "Completed", "Dean's list honors"),
    ]
    sem_ids_s2 = {}
    for sem_no, ac_yr, sgpa, cgpa, st, rem in s2_sems:
        cur = conn.execute(
            """INSERT INTO semesters(student_id, semester_no, academic_year, sgpa, cgpa, status, remarks)
               VALUES(?, ?, ?, ?, ?, ?, ?)""",
            (s2_id, sem_no, ac_yr, sgpa, cgpa, st, rem),
        )
        sem_ids_s2[sem_no] = cur.lastrowid

    # Gap year for Priya
    conn.execute(
        """INSERT INTO gap_years(student_id, start_year, end_year, gap_type, reason)
           VALUES(?, ?, ?, ?, ?)""",
        (
            s2_id,
            2021,
            2022,
            "Medical Leave",
            "Underwent orthopedic knee surgery followed by physiotherapy rehabilitation. Resumed in 2022 academic cycle.",
        ),
    )

    # Student 3: Rohan Patel (Demonstrates missing semester record without false gap year assumption)
    c3 = conn.execute(
        """INSERT INTO students(roll_no, full_name, email, phone, department, admission_year,
                               secondary_percent, higher_secondary_percent, current_semester, current_status)
           VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
        (
            "CE-2022-088",
            "Rohan Patel",
            "rohan.patel@example.edu",
            "+91 98765 43212",
            "Computer Engineering",
            2022,
            79.5,
            76.0,
            5,
            "Active",
        ),
    )
    s3_id = c3.lastrowid

    # Semesters for Rohan: Sem 1 and Sem 3 recorded, Sem 2 deliberately missing
    conn.execute(
        """INSERT INTO semesters(student_id, semester_no, academic_year, sgpa, cgpa, status, remarks)
           VALUES(?, ?, ?, ?, ?, ?, ?)""",
        (s3_id, 1, "2022-2023", 7.80, 7.80, "Completed", "Joined under state quota"),
    )
    conn.execute(
        """INSERT INTO semesters(student_id, semester_no, academic_year, sgpa, cgpa, status, remarks)
           VALUES(?, ?, ?, ?, ?, ?, ?)""",
        (s3_id, 3, "2023-2024", 8.15, 7.97, "Completed", "Grade improvement shown"),
    )

    # Student 4: Ananya Deshmukh (High achiever, graduated)
    c4 = conn.execute(
        """INSERT INTO students(roll_no, full_name, email, phone, department, admission_year,
                               secondary_percent, higher_secondary_percent, current_semester, current_status)
           VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
        (
            "CE-2020-004",
            "Ananya Deshmukh",
            "ananya.d@example.edu",
            "+91 98765 43213",
            "Computer Engineering",
            2020,
            95.2,
            94.0,
            8,
            "Graduated",
        ),
    )
    s4_id = c4.lastrowid
    conn.execute(
        """INSERT INTO semesters(student_id, semester_no, academic_year, sgpa, cgpa, status, remarks)
           VALUES(?, ?, ?, ?, ?, ?, ?)""",
        (s4_id, 8, "2023-2024", 9.80, 9.45, "Completed", "Gold Medalist / College Valedictorian"),
    )

    # Add Subject Marks for Aarav Sharma (Sem 1 & Sem 2 & Sem 3)
    subjects = {
        row["subject_code"]: row["id"]
        for row in conn.execute("SELECT id, subject_code FROM subjects").fetchall()
    }

    # S1 Sem 1 marks (Theory & Lab)
    if 1 in sem_ids_s1:
        conn.execute(
            """INSERT INTO semester_subject_marks(semester_id, subject_id, marks_obtained, max_marks, grade_point)
               VALUES(?, ?, ?, ?, ?)""",
            (sem_ids_s1[1], subjects["CS101"], 86.0, 100.0, 9.0),
        )
        conn.execute(
            """INSERT INTO semester_subject_marks(semester_id, subject_id, marks_obtained, max_marks, grade_point)
               VALUES(?, ?, ?, ?, ?)""",
            (sem_ids_s1[1], subjects["CS102"], 45.0, 50.0, 9.0),
        )

    # S1 Sem 3 marks (DBMS Theory & Lab)
    if 3 in sem_ids_s1:
        conn.execute(
            """INSERT INTO semester_subject_marks(semester_id, subject_id, marks_obtained, max_marks, grade_point)
               VALUES(?, ?, ?, ?, ?)""",
            (sem_ids_s1[3], subjects["CS201"], 92.0, 100.0, 10.0),
        )
        conn.execute(
            """INSERT INTO semester_subject_marks(semester_id, subject_id, marks_obtained, max_marks, grade_point)
               VALUES(?, ?, ?, ?, ?)""",
            (sem_ids_s1[3], subjects["CS202"], 48.0, 50.0, 10.0),
        )

    # S2 (Priya) Sem 1 marks
    if 1 in sem_ids_s2:
        conn.execute(
            """INSERT INTO semester_subject_marks(semester_id, subject_id, marks_obtained, max_marks, grade_point)
               VALUES(?, ?, ?, ?, ?)""",
            (sem_ids_s2[1], subjects["CS101"], 82.0, 100.0, 8.5),
        )
        conn.execute(
            """INSERT INTO semester_subject_marks(semester_id, subject_id, marks_obtained, max_marks, grade_point)
               VALUES(?, ?, ?, ?, ?)""",
            (sem_ids_s2[1], subjects["CS102"], 42.0, 50.0, 8.5),
        )

    # Seminars
    conn.execute(
        """INSERT INTO seminars(student_id, title, seminar_type, seminar_date, organizer, certificate_url)
           VALUES(?, ?, ?, ?, ?, ?)""",
        (
            s1_id,
            "Next-Gen Database Architectures and Distributed Consensus",
            "Internal",
            "2023-09-15",
            "Department of Computer Engineering, ECE Forum",
            "https://drive.google.com/cert/aarav-db-seminar",
        ),
    )
    conn.execute(
        """INSERT INTO seminars(student_id, title, seminar_type, seminar_date, organizer, certificate_url)
           VALUES(?, ?, ?, ?, ?, ?)""",
        (
            s1_id,
            "Microservices and Serverless Infrastructure at Scale",
            "External",
            "2024-02-18",
            "IEEE Computer Society International Chapter",
            "https://ieee.org/certificates/2024/aarav-ms",
        ),
    )
    conn.execute(
        """INSERT INTO seminars(student_id, title, seminar_type, seminar_date, organizer, certificate_url)
           VALUES(?, ?, ?, ?, ?, ?)""",
        (
            s2_id,
            "Assistive Technology and Medical Robotics",
            "Internal",
            "2023-11-20",
            "Biomedical and Robotics Research Group",
            "https://drive.google.com/cert/priya-robotics",
        ),
    )
    conn.execute(
        """INSERT INTO seminars(student_id, title, seminar_type, seminar_date, organizer, certificate_url)
           VALUES(?, ?, ?, ?, ?, ?)""",
        (
            s4_id,
            "Quantum Key Distribution and Post-Quantum Cryptography",
            "External",
            "2024-03-05",
            "National Institute of Technology CyberCon",
            "https://nit.ac.in/cert/ananya-quantum",
        ),
    )

    # Categories lookup
    cats = {
        row["name"]: row["id"]
        for row in conn.execute("SELECT id, name FROM activity_categories").fetchall()
    }

    # Activities
    conn.execute(
        """INSERT INTO activities(student_id, category_id, activity_name, description, activity_date, achievement_level, certificate_ref)
           VALUES(?, ?, ?, ?, ?, ?, ?)""",
        (
            s1_id,
            cats.get("Coding Contest & Hackathon", 1),
            "Smart India Hackathon (SIH 2023)",
            "Developed an automated triage system for rural health centers using edge computing.",
            "2023-10-12",
            "Winner",
            "SIH-2023-WIN-8841",
        ),
    )
    conn.execute(
        """INSERT INTO activities(student_id, category_id, activity_name, description, activity_date, achievement_level, certificate_ref)
           VALUES(?, ?, ?, ?, ?, ?, ?)""",
        (
            s1_id,
            cats.get("Research Paper Presentation", 2),
            "IEEE International Conference on Data Engineering",
            "Presented peer-reviewed research paper on adaptive index selection algorithms in relational DBMS.",
            "2024-01-22",
            "National Level",
            "IEEE-CONF-2024-PAPER-19",
        ),
    )
    conn.execute(
        """INSERT INTO activities(student_id, category_id, activity_name, description, activity_date, achievement_level, certificate_ref)
           VALUES(?, ?, ?, ?, ?, ?, ?)""",
        (
            s2_id,
            cats.get("Student Council & Leadership", 12),
            "Head of Women in Tech Campus Chapter",
            "Organized coding bootcamps for 250+ first-year women engineering students.",
            "2023-08-01",
            "College Level",
            "WIT-COUNCIL-2023",
        ),
    )
    conn.execute(
        """INSERT INTO activities(student_id, category_id, activity_name, description, activity_date, achievement_level, certificate_ref)
           VALUES(?, ?, ?, ?, ?, ?, ?)""",
        (
            s4_id,
            cats.get("Sports & Athletics", 9),
            "Inter-University Table Tennis Championship",
            "Captain of university women's table tennis team; secured silver medal.",
            "2023-12-14",
            "Runner-up",
            "SPORTS-TT-2023-SILVER",
        ),
    )

    # Seed an initial SyncLog entry
    conn.execute(
        """INSERT INTO sync_log(synced_at, sync_type, status, records_synced, message)
           VALUES(?, ?, ?, ?, ?)""",
        (
            datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "System",
            "SUCCESS",
            4,
            "Database initialized and demo data loaded.",
        ),
    )

    print("[database.py] Demonstration records successfully seeded!")


# ============================================================================
# Student CRUD Operations
# ============================================================================

def get_dashboard_stats():
    """
    Returns high-level statistics for dashboard widgets.
    """
    with get_db() as conn:
        total_students = conn.execute("SELECT COUNT(*) FROM students").fetchone()[0]
        total_semesters = conn.execute("SELECT COUNT(*) FROM semesters").fetchone()[0]
        total_seminars = conn.execute("SELECT COUNT(*) FROM seminars").fetchone()[0]
        total_activities = conn.execute("SELECT COUNT(*) FROM activities").fetchone()[0]
        total_gaps = conn.execute("SELECT COUNT(*) FROM gap_years").fetchone()[0]
        active_students = conn.execute(
            "SELECT COUNT(*) FROM students WHERE current_status = 'Active'"
        ).fetchone()[0]
        avg_cgpa_row = conn.execute(
            "SELECT AVG(cgpa) FROM semesters WHERE cgpa IS NOT NULL"
        ).fetchone()[0]
        avg_cgpa = round(avg_cgpa_row, 2) if avg_cgpa_row else 0.0

        # Last sync
        last_sync = conn.execute(
            "SELECT * FROM sync_log ORDER BY id DESC LIMIT 1"
        ).fetchone()

    return {
        "total_students": total_students,
        "total_semesters": total_semesters,
        "total_seminars": total_seminars,
        "total_activities": total_activities,
        "total_gaps": total_gaps,
        "active_students": active_students,
        "avg_cgpa": avg_cgpa,
        "last_sync": last_sync,
    }


def get_students(search_query=None, status_filter=None):
    """
    Fetch all students with optional search by roll number or name,
    and optional status filter. Returns list with calculated latest CGPA.
    """
    with get_db() as conn:
        sql = """
            SELECT s.*, 
                   (SELECT cgpa FROM semesters WHERE student_id = s.id ORDER BY semester_no DESC LIMIT 1) as latest_cgpa,
                   (SELECT COUNT(*) FROM semesters WHERE student_id = s.id) as recorded_semesters,
                   (SELECT COUNT(*) FROM gap_years WHERE student_id = s.id) as gap_count
            FROM students s
            WHERE 1=1
        """
        params = []
        if search_query:
            sql += " AND (s.full_name LIKE ? OR s.roll_no LIKE ? OR s.email LIKE ?)"
            q = f"%{search_query.strip()}%"
            params.extend([q, q, q])
        if status_filter and status_filter != "All":
            sql += " AND s.current_status = ?"
            params.append(status_filter)

        sql += " ORDER BY s.roll_no ASC"
        return conn.execute(sql, params).fetchall()


def get_student_by_id(student_id):
    """
    Fetch single student profile by primary key.
    """
    with get_db() as conn:
        return conn.execute(
            "SELECT * FROM students WHERE id = ?", (student_id,)
        ).fetchone()


def create_student(roll_no, full_name, email, phone, department, admission_year,
                   secondary_percent, higher_secondary_percent, current_semester, current_status):
    """
    Insert a new student profile with data validation.
    """
    with get_db() as conn:
        cur = conn.execute(
            """INSERT INTO students(roll_no, full_name, email, phone, department, admission_year,
                                   secondary_percent, higher_secondary_percent, current_semester, current_status)
               VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                roll_no.strip().upper(),
                full_name.strip(),
                email.strip() if email else None,
                phone.strip() if phone else None,
                department.strip() or "Computer Engineering",
                int(admission_year),
                float(secondary_percent) if secondary_percent is not None and secondary_percent != "" else None,
                float(higher_secondary_percent) if higher_secondary_percent is not None and higher_secondary_percent != "" else None,
                int(current_semester) if current_semester else 1,
                current_status or "Active",
            ),
        )
        return cur.lastrowid


def update_student(student_id, roll_no, full_name, email, phone, department, admission_year,
                   secondary_percent, higher_secondary_percent, current_semester, current_status):
    """
    Update an existing student profile.
    """
    with get_db() as conn:
        conn.execute(
            """UPDATE students
               SET roll_no = ?, full_name = ?, email = ?, phone = ?, department = ?, admission_year = ?,
                   secondary_percent = ?, higher_secondary_percent = ?, current_semester = ?, current_status = ?
               WHERE id = ?""",
            (
                roll_no.strip().upper(),
                full_name.strip(),
                email.strip() if email else None,
                phone.strip() if phone else None,
                department.strip() or "Computer Engineering",
                int(admission_year),
                float(secondary_percent) if secondary_percent is not None and secondary_percent != "" else None,
                float(higher_secondary_percent) if higher_secondary_percent is not None and higher_secondary_percent != "" else None,
                int(current_semester) if current_semester else 1,
                current_status or "Active",
                student_id,
            ),
        )


def delete_student(student_id):
    """
    Delete student profile. ON DELETE CASCADE automatically removes
    semesters, subject marks, seminars, activities, and gap years.
    """
    with get_db() as conn:
        conn.execute("DELETE FROM students WHERE id = ?", (student_id,))


# ============================================================================
# Semester & Marks Operations
# ============================================================================

def get_semesters_for_student(student_id):
    """
    Fetch all semester records for a student ordered by semester_no.
    """
    with get_db() as conn:
        return conn.execute(
            """SELECT s.*, 
                      (SELECT COUNT(*) FROM semester_subject_marks WHERE semester_id = s.id) as subject_count
               FROM semesters s
               WHERE s.student_id = ?
               ORDER BY s.semester_no ASC""",
            (student_id,),
        ).fetchall()


def get_semester_by_id(semester_id):
    """
    Fetch semester by primary key.
    """
    with get_db() as conn:
        return conn.execute(
            "SELECT * FROM semesters WHERE id = ?", (semester_id,)
        ).fetchone()


def add_semester(student_id, semester_no, academic_year, sgpa=None, cgpa=None, status="Completed", remarks=None):
    """
    Insert a semester record. Enforces unique(student_id, semester_no).
    """
    with get_db() as conn:
        cur = conn.execute(
            """INSERT INTO semesters(student_id, semester_no, academic_year, sgpa, cgpa, status, remarks)
               VALUES(?, ?, ?, ?, ?, ?, ?)""",
            (
                student_id,
                int(semester_no),
                academic_year.strip(),
                float(sgpa) if sgpa is not None and sgpa != "" else None,
                float(cgpa) if cgpa is not None and cgpa != "" else None,
                status or "Completed",
                remarks.strip() if remarks else None,
            ),
        )
        return cur.lastrowid


def update_semester(semester_id, semester_no, academic_year, sgpa=None, cgpa=None, status="Completed", remarks=None):
    """
    Update semester performance record.
    """
    with get_db() as conn:
        conn.execute(
            """UPDATE semesters
               SET semester_no = ?, academic_year = ?, sgpa = ?, cgpa = ?, status = ?, remarks = ?
               WHERE id = ?""",
            (
                int(semester_no),
                academic_year.strip(),
                float(sgpa) if sgpa is not None and sgpa != "" else None,
                float(cgpa) if cgpa is not None and cgpa != "" else None,
                status or "Completed",
                remarks.strip() if remarks else None,
                semester_id,
            ),
        )


def delete_semester(semester_id):
    """
    Delete semester record and cascade-delete its subject marks.
    """
    with get_db() as conn:
        conn.execute("DELETE FROM semesters WHERE id = ?", (semester_id,))


def get_subjects():
    """
    Return all master subjects ordered by type and name.
    """
    with get_db() as conn:
        return conn.execute(
            "SELECT * FROM subjects ORDER BY subject_type, subject_name"
        ).fetchall()


def add_subject(subject_code, subject_name, subject_type, credits=3, default_max_marks=100.0):
    """
    Add a master subject to the catalog.
    """
    with get_db() as conn:
        cur = conn.execute(
            """INSERT INTO subjects(subject_code, subject_name, subject_type, credits, default_max_marks)
               VALUES(?, ?, ?, ?, ?)""",
            (
                subject_code.strip().upper(),
                subject_name.strip(),
                subject_type,
                int(credits),
                float(default_max_marks),
            ),
        )
        return cur.lastrowid


def delete_subject(subject_id):
    """
    Delete a master subject.
    """
    with get_db() as conn:
        conn.execute("DELETE FROM subjects WHERE id = ?", (subject_id,))


def get_marks_for_semester(semester_id):
    """
    Fetch all subject marks for a semester with subject details.
    """
    with get_db() as conn:
        return conn.execute(
            """SELECT m.*, sub.subject_code, sub.subject_name, sub.subject_type, sub.credits
               FROM semester_subject_marks m
               JOIN subjects sub ON sub.id = m.subject_id
               WHERE m.semester_id = ?
               ORDER BY sub.subject_type DESC, sub.subject_code ASC""",
            (semester_id,),
        ).fetchall()


def get_all_marks_for_student(student_id):
    """
    Fetch all subject marks for a student across all semesters.
    """
    with get_db() as conn:
        return conn.execute(
            """SELECT m.*, sem.semester_no, sem.academic_year,
                      sub.subject_code, sub.subject_name, sub.subject_type, sub.credits
               FROM semester_subject_marks m
               JOIN semesters sem ON sem.id = m.semester_id
               JOIN subjects sub ON sub.id = m.subject_id
               WHERE sem.student_id = ?
               ORDER BY sem.semester_no ASC, sub.subject_type DESC, sub.subject_code ASC""",
            (student_id,),
        ).fetchall()


def add_or_update_subject_marks(semester_id, subject_id, marks_obtained, max_marks, grade_point=None):
    """
    Insert or update marks for a subject in a semester.
    Automatically computes grade_point if not provided: (marks_obtained / max_marks) * 10.
    """
    mo = float(marks_obtained)
    mm = float(max_marks)
    if mo < 0 or mm <= 0 or mo > mm:
        raise ValueError("Marks obtained must be between 0 and maximum marks.")

    gp = float(grade_point) if grade_point is not None and grade_point != "" else round((mo / mm) * 10.0, 2)

    with get_db() as conn:
        conn.execute(
            """INSERT INTO semester_subject_marks(semester_id, subject_id, marks_obtained, max_marks, grade_point)
               VALUES(?, ?, ?, ?, ?)
               ON CONFLICT(semester_id, subject_id) DO UPDATE SET
                   marks_obtained = excluded.marks_obtained,
                   max_marks = excluded.max_marks,
                   grade_point = excluded.grade_point""",
            (semester_id, int(subject_id), mo, mm, gp),
        )


def delete_subject_mark(mark_id):
    """
    Delete a subject mark record.
    """
    with get_db() as conn:
        conn.execute("DELETE FROM semester_subject_marks WHERE id = ?", (mark_id,))


# ============================================================================
# Portfolio: Seminars, Activities, Gap Years
# ============================================================================

def get_seminars_for_student(student_id):
    """
    Fetch all seminars for a student.
    """
    with get_db() as conn:
        return conn.execute(
            "SELECT * FROM seminars WHERE student_id = ? ORDER BY seminar_date DESC",
            (student_id,),
        ).fetchall()


def get_all_seminars(seminar_type=None, search_query=None):
    """
    Fetch all seminars across students with student details for global portfolio view.
    """
    with get_db() as conn:
        sql = """
            SELECT sem.*, st.roll_no, st.full_name as student_name
            FROM seminars sem
            JOIN students st ON st.id = sem.student_id
            WHERE 1=1
        """
        params = []
        if seminar_type and seminar_type != "All":
            sql += " AND sem.seminar_type = ?"
            params.append(seminar_type)
        if search_query:
            sql += " AND (sem.title LIKE ? OR sem.organizer LIKE ? OR st.full_name LIKE ?)"
            q = f"%{search_query.strip()}%"
            params.extend([q, q, q])
        sql += " ORDER BY sem.seminar_date DESC"
        return conn.execute(sql, params).fetchall()


def add_seminar(student_id, title, seminar_type, seminar_date, organizer, certificate_url=None):
    """
    Record an internal or external seminar.
    """
    with get_db() as conn:
        cur = conn.execute(
            """INSERT INTO seminars(student_id, title, seminar_type, seminar_date, organizer, certificate_url)
               VALUES(?, ?, ?, ?, ?, ?)""",
            (
                student_id,
                title.strip(),
                seminar_type,
                seminar_date.strip(),
                organizer.strip(),
                certificate_url.strip() if certificate_url else None,
            ),
        )
        return cur.lastrowid


def delete_seminar(seminar_id):
    """
    Delete a seminar record.
    """
    with get_db() as conn:
        conn.execute("DELETE FROM seminars WHERE id = ?", (seminar_id,))


def get_activity_categories():
    """
    Fetch all normalized activity categories.
    """
    with get_db() as conn:
        return conn.execute(
            "SELECT * FROM activity_categories ORDER BY activity_type, name"
        ).fetchall()


def get_activities_for_student(student_id, activity_type=None):
    """
    Fetch activities for a student with category details.
    """
    with get_db() as conn:
        sql = """
            SELECT a.*, c.name as category_name, c.activity_type
            FROM activities a
            JOIN activity_categories c ON c.id = a.category_id
            WHERE a.student_id = ?
        """
        params = [student_id]
        if activity_type:
            sql += " AND c.activity_type = ?"
            params.append(activity_type)
        sql += " ORDER BY a.activity_date DESC"
        return conn.execute(sql, params).fetchall()


def get_all_activities(activity_type=None, search_query=None):
    """
    Fetch all activities across all students with student details.
    """
    with get_db() as conn:
        sql = """
            SELECT a.*, c.name as category_name, c.activity_type, st.roll_no, st.full_name as student_name
            FROM activities a
            JOIN activity_categories c ON c.id = a.category_id
            JOIN students st ON st.id = a.student_id
            WHERE 1=1
        """
        params = []
        if activity_type and activity_type != "All":
            sql += " AND c.activity_type = ?"
            params.append(activity_type)
        if search_query:
            sql += " AND (a.activity_name LIKE ? OR a.description LIKE ? OR st.full_name LIKE ?)"
            q = f"%{search_query.strip()}%"
            params.extend([q, q, q])
        sql += " ORDER BY a.activity_date DESC"
        return conn.execute(sql, params).fetchall()


def add_activity(student_id, category_id, activity_name, description, activity_date, achievement_level, certificate_ref=None):
    """
    Record a student activity (technical, co-curricular, or extra-curricular).
    """
    with get_db() as conn:
        cur = conn.execute(
            """INSERT INTO activities(student_id, category_id, activity_name, description, activity_date, achievement_level, certificate_ref)
               VALUES(?, ?, ?, ?, ?, ?, ?)""",
            (
                student_id,
                int(category_id),
                activity_name.strip(),
                description.strip() if description else None,
                activity_date.strip(),
                achievement_level or "Participant",
                certificate_ref.strip() if certificate_ref else None,
            ),
        )
        return cur.lastrowid


def delete_activity(activity_id):
    """
    Delete an activity record.
    """
    with get_db() as conn:
        conn.execute("DELETE FROM activities WHERE id = ?", (activity_id,))


def get_gap_years_for_student(student_id):
    """
    Fetch all academic drop/gap years for a student.
    """
    with get_db() as conn:
        return conn.execute(
            "SELECT * FROM gap_years WHERE student_id = ? ORDER BY start_year ASC",
            (student_id,),
        ).fetchall()


def add_gap_year(student_id, start_year, end_year, gap_type, reason):
    """
    Record an academic gap year. Validates that end_year >= start_year.
    """
    sy = int(start_year)
    ey = int(end_year)
    if ey < sy:
        raise ValueError("End year cannot be earlier than start year.")

    with get_db() as conn:
        cur = conn.execute(
            """INSERT INTO gap_years(student_id, start_year, end_year, gap_type, reason)
               VALUES(?, ?, ?, ?, ?)""",
            (
                student_id,
                sy,
                ey,
                gap_type or "Academic Drop",
                reason.strip(),
            ),
        )
        return cur.lastrowid


def delete_gap_year(gap_id):
    """
    Delete a gap year entry.
    """
    with get_db() as conn:
        conn.execute("DELETE FROM gap_years WHERE id = ?", (gap_id,))


# ============================================================================
# Synchronization Audit Logging & Progression Data Exporter
# ============================================================================

def log_sync(status, records_synced, message, sync_type="Manual"):
    """
    Record synchronization audit trail in sync_log table.
    """
    with get_db() as conn:
        cur = conn.execute(
            """INSERT INTO sync_log(synced_at, sync_type, status, records_synced, message)
               VALUES(?, ?, ?, ?, ?)""",
            (
                datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                sync_type,
                status,
                int(records_synced),
                str(message),
            ),
        )
        return cur.lastrowid


def get_sync_logs(limit=25):
    """
    Fetch latest synchronization audit logs.
    """
    with get_db() as conn:
        return conn.execute(
            "SELECT * FROM sync_log ORDER BY id DESC LIMIT ?", (limit,)
        ).fetchall()


def get_last_sync():
    """
    Fetch the most recent sync record.
    """
    with get_db() as conn:
        return conn.execute(
            "SELECT * FROM sync_log ORDER BY id DESC LIMIT 1"
        ).fetchone()


def get_progression_export_data():
    """
    Generates a flattened, joined dataset of student profiles and semester
    progression for CSV export and Google Sheets synchronization.
    Includes:
    Roll No, Student Name, Email, Phone, Department, Admission Year,
    Secondary % (10th), Higher Secondary % (12th), Status,
    Semester No, Academic Year, SGPA, CGPA, Semester Status, Remarks,
    Recorded Gap Years Summary.
    """
    with get_db() as conn:
        sql = """
            SELECT 
                st.roll_no,
                st.full_name,
                st.email,
                st.phone,
                st.department,
                st.admission_year,
                st.secondary_percent,
                st.higher_secondary_percent,
                st.current_status,
                sem.semester_no,
                sem.academic_year,
                sem.sgpa,
                sem.cgpa,
                sem.status as semester_status,
                sem.remarks,
                (SELECT GROUP_CONCAT(start_year || '-' || end_year || ' (' || gap_type || ': ' || reason || ')', '; ')
                 FROM gap_years WHERE student_id = st.id) as gap_years_summary
            FROM students st
            LEFT JOIN semesters sem ON sem.student_id = st.id
            ORDER BY st.roll_no ASC, sem.semester_no ASC
        """
        return conn.execute(sql).fetchall()
